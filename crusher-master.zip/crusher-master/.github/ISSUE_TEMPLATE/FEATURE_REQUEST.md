---
name: "\U0001F941  Feature request"
about: Raise a feature request
title: ""
labels: feature, improvement
assignees: ""
---

**Describe the feature**

**Any docs or video for this**

**What's expected behaviour**

**Who should implement this**

**Describe priority**
