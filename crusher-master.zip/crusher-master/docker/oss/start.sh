./node_modules/pm2/bin/pm2 start
alias pm2="./node_modules/pm2/bin/pm2"
while true; do sleep 1000; done