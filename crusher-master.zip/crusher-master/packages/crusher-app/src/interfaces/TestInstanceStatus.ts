export enum TestInstanceStatus {
	"QUEUED" = "QUEUED",
	"RUNNING" = "RUNNING",
	"FINISHED" = "FINISHED",
	"TIMEOUT" = "TIMEOUT",
	"ABORTED" = "ABORTED",
}
