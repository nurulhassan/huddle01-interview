export const PERSON_TYPE: any = {
	DEVELOPER: "Developer",
	FOUNDER: "Founder",
	QA: "QA",
	MANAGER: "Manager",
	OTHER: "Other",
};

export const WHY_HERE: any = {
	SPEED: "Write and test with speed",
	STABILITY: "Get more stability in software",
	IMPROVE_QA: "Imrove QA Process",
	DECREASE_TESTING_COST: "Decrease testing cost",
	IMPROVE_OBSEVABILITY: "Improve Observability",
};

export const WHAT_DO_YOU_WANT_TO_TEST = {
	APP: "APP",
	API: "API",
	WEB: "WEB",
};
