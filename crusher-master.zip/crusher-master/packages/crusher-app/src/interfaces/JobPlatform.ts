export enum JobPlatform {
	CHROME = "CHROME",
	FIREFOX = "FIREFOX",
	SAFARI = "SAFARI",
	ALL = "ALL",
}
