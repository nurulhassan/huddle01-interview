export interface MonitoringSettings {
	id?: number;
	target_host: number;
	platform: any;
	test_interval: string;
	project_id: number;
	last_cron_run?: any;
	created_at?: any;
	updated_at?: any;
}
