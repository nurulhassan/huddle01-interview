export interface iMember {
	id: number;
	name: string;
	email: string;
	role: string;
}

export interface iProfile {
	id: number;
	name: string;
	email: string;
}
