export interface iGithubInstallation {
	label: string;
	value: number;
}
