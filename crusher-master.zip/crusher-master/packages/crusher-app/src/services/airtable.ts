export default class Airtable {}
