export enum PAGE_TYPE {
	BUILD_PAGE = "Build Page",
}
