const lastBuild = (state = {}, action) => {
	switch (action.type) {
		default:
			return state;
	}
};

export default lastBuild;
