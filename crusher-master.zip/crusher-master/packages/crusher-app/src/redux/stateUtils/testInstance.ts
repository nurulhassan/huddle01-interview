export const getAllTestInstancesLogs = (state) => state.testInstance.logs;
