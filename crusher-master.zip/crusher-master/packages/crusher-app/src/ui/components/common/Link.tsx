export const StandardLink = ({ children, link }) => {
	return <a href={link}>{children}</a>;
};
