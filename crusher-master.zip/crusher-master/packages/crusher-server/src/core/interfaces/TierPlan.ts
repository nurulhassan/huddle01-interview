export enum TierPlan {
	FREE = "FREE",
	STARTER = "STARTER",
	PRO = "PRO",
}
