export enum Platform {
	CHROME = "CHROME",
	FIREFOX = "FIREFOX",
	SAFARI = "SAFARI",
	ALL = "ALL",
}
