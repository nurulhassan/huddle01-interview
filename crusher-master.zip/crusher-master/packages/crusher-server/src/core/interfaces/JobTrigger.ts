export enum JobTrigger {
	MANUAL = "MANUAL",
	CRON = "CRON",
	CLI = "CLI",
	MONITORING = "MONITORING",
}
