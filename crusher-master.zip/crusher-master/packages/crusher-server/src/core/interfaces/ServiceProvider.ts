export enum ServiceProvider {
	GITHUB = "GITHUB",
	GITLAB = "GTILAB",
}
