export enum ScreenShotComparisionStatus {
	PASSED = "PASSED",
	FAILED = "FAILED",
	CHECK_NOT_PERFORMED = "CHECK_NOT_PERFORMED",
}
