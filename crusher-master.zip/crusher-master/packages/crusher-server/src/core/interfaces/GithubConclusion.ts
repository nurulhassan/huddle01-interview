export enum GithubConclusion {
	SUCCESS = "success",
	FAILURE = "failure",
}
