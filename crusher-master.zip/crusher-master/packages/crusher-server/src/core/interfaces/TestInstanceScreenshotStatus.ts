export enum TestInstanceScreenshotStatus {
	CHECK_NOT_PERFORMED = "CHECK_NOT_PERFORMED",
	PASSED = "PASSED",
	FAILED = "FAILED",
}
