export enum GithubCheckStatus {
	IN_PROGRESS = "in_progress",
	QUEUED = "queued",
	COMPLETED = "completed",
}
