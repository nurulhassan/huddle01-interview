export enum TestType {
	DRAFT = "DRAFT",
	SAVED = "SAVED",
}
