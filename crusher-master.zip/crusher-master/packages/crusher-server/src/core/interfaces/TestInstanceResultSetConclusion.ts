export enum TestInstanceResultSetConclusion {
	PASSED = "PASSED",
	FAILED = "FAILED",
	MANUAL_REVIEW_REQUIRED = "MANUAL_REVIEW_REQUIRED",
}
