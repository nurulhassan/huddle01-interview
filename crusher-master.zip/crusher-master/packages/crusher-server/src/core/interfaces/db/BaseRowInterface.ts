export interface BaseRowInterface {
	created_at?: any;
	updated_at?: any;
}
