export enum InstanceStatus {
	"QUEUED" = "QUEUED",
	"RUNNING" = "RUNNING",
	"FINISHED" = "FINISHED",
	"TIMEOUT" = "TIMEOUT",
	"ABORTED" = "ABORTED",
}
