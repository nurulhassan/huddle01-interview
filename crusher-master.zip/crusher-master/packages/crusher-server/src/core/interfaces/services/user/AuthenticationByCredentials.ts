export interface AuthenticationByCredentials {
	email: string;
	password: string;
}
