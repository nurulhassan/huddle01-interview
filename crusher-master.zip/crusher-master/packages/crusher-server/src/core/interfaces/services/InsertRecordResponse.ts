export interface InsertRecordResponse {
	insertId: number;
}
