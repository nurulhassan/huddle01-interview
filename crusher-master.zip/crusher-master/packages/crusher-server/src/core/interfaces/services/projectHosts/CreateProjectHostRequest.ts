export interface CreateProjectHostRequest {
	name: string;
	url: string;
	projectId: number;
	userId: number;
}
