export const AWS_BUCKET_REGION = process.env.AWS_S3_REGION ? process.env.AWS_S3_REGION : "us-east-1";
export const AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID ? process.env.AWS_ACCESS_KEY_ID : "AKIAJ42YYRK2DES5CSPQ";
export const AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY ? process.env.AWS_SECRET_ACCESS_KEY : "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";
export const AWS_S3_VIDEO_BUCKET = process.env.AWS_S3_VIDEO_BUCKET ? process.env.AWS_S3_VIDEO_BUCKET : "crusher-videos";
