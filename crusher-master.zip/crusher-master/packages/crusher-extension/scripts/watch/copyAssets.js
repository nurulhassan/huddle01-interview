const tasks = require("../tasks");

tasks.copyAssets("dev");
