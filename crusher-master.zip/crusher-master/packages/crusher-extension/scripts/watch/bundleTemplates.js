const tasks = require("../tasks");

tasks.bundleTemplates("dev");
