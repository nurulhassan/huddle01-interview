export interface iOnboardingState {
	isComplete: boolean;
	currentStep: number;
}
