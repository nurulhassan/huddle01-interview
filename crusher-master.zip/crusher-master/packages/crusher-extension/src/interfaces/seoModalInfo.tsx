import { iPageSeoMeta } from "../utils/dom";

export interface iSeoModalInfo {
	pageTitle: string;
	metaTags: iPageSeoMeta;
}
