export interface IEventMutationRecord {
	eventNode: Node;
	type: string;
	key: string;
	targetNode: Node;
}
