// custom typefaces
import "./src/styling/style.css"
